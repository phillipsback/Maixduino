prepend `common.cmake` before

append `executable.cmake` after
