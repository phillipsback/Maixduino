#ifndef __MBNET_NAMES_H
#define __MBNET_NAMES_H

extern const char* mbnet_label_name[];

#endif

